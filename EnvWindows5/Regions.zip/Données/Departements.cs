﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnvWindows5.Données
{
    class Departements : Dictionary<Region, List<String>>
    {
        public void chargementDepartements()
        {
            Regions reg = new Regions();

            reg.chargermentRegions();

            foreach (Region r in reg)
            {
                this.Add(r, new List<String>{r + "1", r + "2"});
            }
        }
    }
}
