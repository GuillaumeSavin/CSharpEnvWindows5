﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnvWindows5.Données
{
    class Regions : ObservableCollection<Region>
    {
        public void chargermentRegions()
        {
            this.Add(new Region("ARA"));
            this.Add(new Region("BFC"));
            this.Add(new Region("B"));
            this.Add(new Region("CVL"));
            this.Add(new Region("C"));
        }
    }
}
