﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EnvWindows5
{
    class Region
    {
        private String nom;

        public Region(String _nom)
        {
            this.nom = _nom;
        }

        public String RegionString
        {
            get
            {
                return nom;
            }
        }
    }
}
